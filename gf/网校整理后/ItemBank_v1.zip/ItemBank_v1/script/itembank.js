// JavaScript Document

$(function(){

	//内页导航
	$('.ibnav h2').click(function() {
		$('.ibnav_list').slideToggle();
	});

	//secTabs切换
	$(".J_secTabs").each(function(){
		var timeout = 300;
		var delay = 0;
		var a = $(this).find("li"), b = $(this).next().children(), c = $(this).find("em"); 

		//a.hover(function(){ var	obj = $(this); item_show(obj); },function(){ item_hide(); });
		a.click(function(){ var	obj = $(this); item_show(obj); },function(){ item_hide(); });
		a.click(function(){ var obj = $(this); item_action(obj); });

		function item_action(obj){
			a.removeClass("selected");
			c.css("cursor","")
			obj.addClass("selected");
			obj.children("em").css("cursor","default");
			var i = a.index(obj);
			b.hide();
			$(b.get(i)).show();
		}
		function item_show(obj){
			clearTimeout(delay);
			delay = setTimeout(function(){
				item_action(obj);
				clearTimeout(delay);
			},timeout);
		}
		function item_hide(){
			clearTimeout(delay);
		}
	});

	//弹出窗口

	var w=document.body.clientWidth;
	var bdh=document.body.offsetHeight;
	var h=$(window).height();
	var boxh=h-120;

	$(".ibtop01pop").css('height',bdh);

	if (w<=768){
		$(".popboxcon").css('height',h-10);
	}else{
		$(".popboxcon").css('height',boxh);
	}

	$(".ibtop01pop").click(function(){
		$(".popbox")
	})
	$("#closebox").click(function(){
		$(".popbox").slideDown();
	})

	// 模态窗口
	/*function autoPlay(){
		$('.screen').css({
			'height':$(window).height(),
		})

		 if($('.screen').is(':hidden')){
		 	$ (window).unbind ('scroll');
		 }else{
		 	$ (window).scroll(function(){
			 	$ (this).scrollTop (0);
			 	console.log("456");
			 })
		 }
	}
	autoPlay();
	 // 关闭窗口
	 $('.tc_title i').click(function(event) {
	 	 $('.screen').stop().hide();
	 	 autoPlay();
	 });*/

	var h1=$('.echart').height();
	$('.ibev_score,.qnum').css({
		'height':h1,
	})

	 $('.ibev_score .circle,.qnum .circle').each(function(index, el) {
        // var num = $(this).find('span').text() * 3.6;
        var num = 0;
        num=80 * 3.6;
        if (num<=180) {
            $(this).find('.right').css('transform', "rotate(" + num + "deg)");
        } else {
            $(this).find('.right').css('transform', "rotate(180deg)");
            $(this).find('.left').css('transform', "rotate(" + (num - 180) + "deg)");
        };
    });

})